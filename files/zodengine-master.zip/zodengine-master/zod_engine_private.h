/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef ZOD_ENGINE_PRIVATE_H
#define ZOD_ENGINE_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"0.1.1.140"
#define VER_MAJOR	0
#define VER_MINOR	1
#define VER_RELEASE	1
#define VER_BUILD	140
#define COMPANY_NAME	"Nighsoft"
#define FILE_VERSION	""
#define FILE_DESCRIPTION	"An open source engine for the game Z by The Bitmap Brothers"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	""
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"The Zod Engine"
#define PRODUCT_VERSION	""

#endif /*ZOD_ENGINE_PRIVATE_H*/
